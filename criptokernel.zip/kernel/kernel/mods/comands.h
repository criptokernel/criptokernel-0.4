void echo(char *args) {
    print_string(args);
    print_string("\n");
}

