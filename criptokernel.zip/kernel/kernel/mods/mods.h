#include "clean.h"
#include "comands.h"
typedef struct {
    const char *name;
    void (*func)(char *args);
} ModCommand;

ModCommand mods_list[] = {
    { "echo",  echo },
    { "clear", clean },
};

#define NUM_MODS (sizeof(mods_list) / sizeof(ModCommand))

