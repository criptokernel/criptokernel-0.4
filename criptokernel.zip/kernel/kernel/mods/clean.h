#define VGA_ADDR 0xB8000
#define VGA_SIZE (80 * 25 * 2)
void clean(){
    unsigned char* mem = (unsigned char *)VGA_ADDR;
    for(int i = 0;i<VGA_SIZE;i++){
        mem[i] = 0x00;
    }
}
