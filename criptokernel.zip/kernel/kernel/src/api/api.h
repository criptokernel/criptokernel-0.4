#ifndef API_H
#define API_H
#include "../src/syscall.h"

#define BUF 4096



#endif
