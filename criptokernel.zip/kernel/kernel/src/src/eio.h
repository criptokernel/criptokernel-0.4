#ifndef EIO_H
#define EIO_H

#include <stdint.h>

// Modo de operação
typedef enum {
    EIO_READ,
    EIO_WRITE
} eio_mode_t;

// Inicializa todo o sistema externo
void eio_init();

// Envia pacote Ethernet bruto
void eio_send(const void* data, uint16_t len);

// Recebe pacote Ethernet (retorna tamanho)
uint16_t eio_recv(void* buffer, uint16_t max_len);

// Verifica se existe pacote pendente
int eio_has_packet();



#include "eio.h"
#include "stdint.h"

#define E1000_REG_BASE   0xF0000000  // MMIO base (QEMU dá isso)
volatile uint32_t* e1000 = (volatile uint32_t*) E1000_REG_BASE;

// ============================================================
//   REGISTROS DO E1000
// ============================================================
#define E1000_TDBAL   0x3800   // Address low TX descriptor
#define E1000_TDBAH   0x3804   // Address high TX descriptor
#define E1000_TDLEN   0x3808   // Tamanho da fila
#define E1000_TDH     0x3810   // Head
#define E1000_TDT     0x3818   // Tail
#define E1000_TCTL    0x400
#define E1000_TIPG    0x410

#define E1000_RDBAL   0x2800
#define E1000_RDBAH   0x2804
#define E1000_RDLEN   0x2808
#define E1000_RDH     0x2810
#define E1000_RDT     0x2818
#define E1000_RCTL    0x100
#define E1000_RAH0    0x5400
#define E1000_RAL0    0x5400

// ============================================================
//   DESCRITORES
// ============================================================
typedef struct {
    uint64_t addr;
    uint16_t length;
    uint8_t cso;
    uint8_t cmd;
    uint8_t status;
    uint8_t css;
    uint16_t special;
} __attribute__((packed)) e1000_tx_desc_t;

typedef struct {
    uint64_t addr;
    uint16_t length;
    uint16_t csum;
    uint8_t status;
    uint8_t errors;
    uint16_t special;
} __attribute__((packed)) e1000_rx_desc_t;

// ============================================================
//   FILAS
// ============================================================
#define NUM_TX  32
#define NUM_RX  32

static e1000_tx_desc_t tx_desc[NUM_TX];
static e1000_rx_desc_t rx_desc[NUM_RX];
static uint8_t tx_buf[NUM_TX][2048];
static uint8_t rx_buf[NUM_RX][2048];

// ============================================================
//   HELPERS
// ============================================================

static inline void reg_write(uint32_t reg, uint32_t val) {
    e1000[reg / 4] = val;
}

static inline uint32_t reg_read(uint32_t reg) {
    return e1000[reg / 4];
}

// ============================================================
//   INIT DO E1000
// ============================================================
void e1000_init() {
    // ============================
    // TX RING
    // ============================
    for (int i = 0; i < NUM_TX; i++) {
        tx_desc[i].addr = (uint64_t)&tx_buf[i][0];
        tx_desc[i].cmd = 0;
        tx_desc[i].status = 1; // livre
    }

    reg_write(E1000_TDBAL, (uint32_t)tx_desc);
    reg_write(E1000_TDBAH, 0);
    reg_write(E1000_TDLEN, sizeof(tx_desc));
    reg_write(E1000_TDH, 0);
    reg_write(E1000_TDT, 0);

    reg_write(E1000_TCTL,
        (1 << 1) |   // EN
        (1 << 3) |   // PSP
        (0x10 << 12) // CT
    );
    reg_write(E1000_TIPG, 10 | (10 << 10) | (10 << 20));

    // ============================
    // RX RING
    // ============================
    for (int i = 0; i < NUM_RX; i++) {
        rx_desc[i].addr = (uint64_t)&rx_buf[i][0];
        rx_desc[i].status = 0;
    }

    reg_write(E1000_RDBAL, (uint32_t)rx_desc);
    reg_write(E1000_RDBAH, 0);
    reg_write(E1000_RDLEN, sizeof(rx_desc));
    reg_write(E1000_RDH, 0);
    reg_write(E1000_RDT, NUM_RX - 1);

    reg_write(E1000_RCTL,
        (1 << 1) |   // EN
        (1 << 15) |  // Bsize 2048
        (1 << 26) |  // SECRC
        (1 << 25)    // LPE
    );
}

// ============================================================
//   WRAPPER EIO
// ============================================================

void eio_init() {
    e1000_init();
}

void eio_send(const void* data, uint16_t len) {
    uint32_t tail = reg_read(E1000_TDT);

    // Copiar dados
    for (int i = 0; i < len; i++)
        tx_buf[tail][i] = ((uint8_t*)data)[i];

    tx_desc[tail].length = len;
    tx_desc[tail].cmd = (1 << 0) | (1 << 3); // EOP + IFCS
    tx_desc[tail].status = 0;

    // Avança o tail
    uint32_t new_tail = (tail + 1) % NUM_TX;
    reg_write(E1000_TDT, new_tail);

    // Espera envio
    while (!(tx_desc[tail].status & 1)) {}
}

uint16_t eio_recv(void* buffer, uint16_t max_len) {
    uint32_t tail = reg_read(E1000_RDT);
    uint32_t next = (tail + 1) % NUM_RX;

    if (!(rx_desc[next].status & 1))
        return 0; // nada

    uint16_t size = rx_desc[next].length;
    if (size > max_len) size = max_len;

    for (int i = 0; i < size; i++)
        ((uint8_t*)buffer)[i] = rx_buf[next][i];

    rx_desc[next].status = 0;
    reg_write(E1000_RDT, next);

    return size;
}

int eio_has_packet() {
    uint32_t tail = reg_read(E1000_RDT);
    uint32_t next = (tail + 1) % NUM_RX;
    return (rx_desc[next].status & 1);
}

#endif

