#include "./kernel/kernel.h"
void shutdown() {
    uint16_t data = 0x2000;
    asm volatile ("outw %0, %1" : : "a"(data), "Nd"(0x604));
}


void check_power_event() {
    if (inw(0xB004) == 0x2000) {   // QEMU ACPI PM event
        shutdown();
    }
}


void kmain(void) {
    // Limpar tela
    volatile char* video_memory = (volatile char*)0xB8000;
    for (int i = 0; i < 80 * 25 * 2; i += 2) {
        video_memory[i] = ' ';
        video_memory[i + 1] = 0x07;
    }  

    
    while (1) {
        run();
        check_power_event(); // verifica se ACPI mandou desligar 
    }   
}      
