void write(char* c){
    print_string(c);
}
void read(char* buf){
    input_string(buf,4096);
}
void clear(){
    clean();
}

void exit(){
    shutdown();
}

void syscall(int sys,char* in){
    if(sys == 0){
        write(in);
    }
    else if(sys == 1){
        read(in);
    }
    else if(sys == 2){
        clear();
    }
    else if(sys == 3){
        exit();
    }
    else {
        print_string("not exist");
    }
}
