#include "../api/api.h"

void run(){
    char buf[BUF];
    syscall(1,buf);
    syscall(0,buf);
}
