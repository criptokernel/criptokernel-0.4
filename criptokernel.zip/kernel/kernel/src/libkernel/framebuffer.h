#ifndef FRAMEBUFFER_H
#define FRAMEBUFFER_H
#include <stdint.h>

// Variáveis globais
extern uint32_t* framebuffer;
extern int fb_width;
extern int fb_height;

// Protótipos
void fb_init();
void putpixel(int x, int y, uint32_t color);
void draw_rect(int x, int y, int w, int h, uint32_t color);
void fill_screen(uint32_t color);


// Definição das variáveis globais
uint32_t* framebuffer = (uint32_t*)0xE0000000; // endereço VBE padrão
int fb_width = 640;
int fb_height = 480;

// Inicializa o framebuffer
void fb_init() {
    // Se você tiver Multiboot info ou VESA info, use aqui
    // Exemplo:
    // framebuffer = (uint32_t*)multiboot_info->framebuffer_addr;
    // fb_width = multiboot_info->framebuffer_width;
    // fb_height = multiboot_info->framebuffer_height;

    // Por enquanto, usa valores fixos
    framebuffer = (uint32_t*)0xE0000000;
    fb_width = 640;
    fb_height = 480;
}

// Desenha um pixel
void putpixel(int x, int y, uint32_t color){
    if(x < 0 || x >= fb_width || y < 0 || y >= fb_height) return;
    framebuffer[y * fb_width + x] = color;
}

// Desenha um retângulo
void draw_rect(int x, int y, int w, int h, uint32_t color){
    for(int i=0;i<h;i++)
        for(int j=0;j<w;j++)
            putpixel(x+j,y+i,color);
}

// Preenche a tela inteira com uma cor
void fill_screen(uint32_t color){
    for(int y=0;y<fb_height;y++)
        for(int x=0;x<fb_width;x++)
            putpixel(x,y,color);
}

#endif

